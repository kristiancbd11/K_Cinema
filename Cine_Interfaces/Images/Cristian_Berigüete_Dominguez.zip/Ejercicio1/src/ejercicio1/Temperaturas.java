package ejercicio1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.file.spi.FileSystemProvider;
import java.util.Random;
import java.util.Scanner;

public class Temperaturas {
	//A partir del siguiente código genera los métodos necesarios para cubrir cada apartado.
	//El manejo de excepciones se tiene que realizar en cada método
	public static void main(String[] args) {
		generaFicheroTempTexto();
		System.out.println("*************************************************************************");
		System.out.println("Leo del fichero temperaturas.txt...");
		int[] resumen = leeFicheroTempTexto();//devuelve en un array el resumen de cada estacion 0:verano 1:otoño y 2:invierno
		System.out.println("Resultados para verano, otoño e invierno:"+resumen[0]+" "+resumen[1]+" "+resumen[2]);
		System.out.println("*************************************************************************");
		System.out.println("Escribiendo en fichero temperaturas.bin...");
		escribeFicheroAleatorio(resumen);//escribe en fichero aleatorio el resumen sacado del fichero de texto anterior
		System.out.println("*************************************************************************");
		System.out.println("Leo y muestro del fichero temperaturas.bin...");
		leerMostrarFicheroAleatorio(); //lee y muestra por pantalla la informacion del fichero binario aleatorio
		System.out.println("*************************************************************************");
		System.out.println("Busco y muestro en el fichero temperaturas.bin...");
		buscarFicheroAleatorio();//busca y muestra por pantalla el resumen de la estacion que le pedira por teclado al usuario
	}

	private static void buscarFicheroAleatorio() {
		try {
			//Cramos los objetos necesarios para el programa
			Scanner sc = new Scanner(System.in);
			File fbin = new File("res/temperaturas.bin");
			RandomAccessFile randf = new RandomAccessFile(fbin, "r");
			
			//Pedimos al usuario el resumen que quiere que sea leido
			System.out.println("¿Qué resumen quiere ver?");
			String resumen = sc.next();
			
			//colocamos el puntero al principio del programa
			randf.seek(0);
			while(randf.getFilePointer() < randf.length()) { //iteramos sobre nuestro documento para ir obteniendo su contenido
				String linea = randf.readUTF(); //aquí guardamos la linea completa que recibimos con el lector
				
				int cortar = linea.indexOf(":"); //tomamos el índice de ":" para cortar nuestro string
				String palabraClave = linea.substring(0, cortar); //tomamos la parte por delante del índice que contiene la palabra buscada
				String valor = linea.substring(cortar, linea.length()); //guardamos el resto del string pues contiene el valor a devolver
				if (resumen.equalsIgnoreCase(palabraClave)) {
					System.out.println("El resumen para " + palabraClave + " es" + valor);; //imprimos el resultado por pantalla en caso de que la palabra buscada coincida con la que nos pasó el usuario
				}
				
			}
			
			/*for(int i = 0; i < randf.length(); i++) {
				randf.seek(i);
				if(randf.readUTF().equalsIgnoreCase(resumen)) {
					randf.seek(i);
					String cadena = randf.readUTF();
					System.out.println("El resumen para " + cadena);			
				}
				
			}*/
			
		} catch (EOFException e) {
			System.out.println("Final del archivo: " + e);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
	}

	private static void leerMostrarFicheroAleatorio() {
		try {
			File fbin = new File("res/temperaturas.bin");
			FileInputStream fIn = new FileInputStream(fbin);
			DataInputStream dIn = new DataInputStream(fIn);
			
			try {
				while(true) { //creamos un bucle infinto para ir leyendo cada linea de nuestro documento. Más abajo manejaremos la excepción
					System.out.println(dIn.readUTF());
				}
			} catch (EOFException e ){
				System.out.println("Final del archivo: " + e); //manejo de la excepcion end of file
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void escribeFicheroAleatorio(int[] resumen) {
		try {
			File fbin = new File("res/temperaturas.bin");
			FileOutputStream fOut = new FileOutputStream(fbin);
			DataOutputStream dOut = new DataOutputStream(fOut);
			
			//Puesto que hemos organizado anteriormente los valores en el array ya sabemos cual corresponde a cada estaciónj, 
			//por lo que simplemente escribimos los valores del array en el mismo orden que vienen y detrás de una cadena que
			//contiene el nombre de la estación.
			
			dOut.writeUTF("Verano: " + resumen[0]);
			dOut.writeUTF("Otoño: " + resumen[1]);
			dOut.writeUTF("Invierno: " + resumen[2]);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}



	// Lee del fichero de texto todas las temperaturas y devuelve cuántas hay de
	// cada tipo
	// Posición 0 para verano, posición 1 para otoño y posición 2 para invierno
	private static int[] leeFicheroTempTexto() {
		int [] resultado = new int [3];
		try {
			File f = new File("res/temperaturas.txt");
			FileReader fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);
			
			String linea;
			
			//Preparamos contadores para cada posible estación
			int verano = 0;
			int invierno = 0;
			int otonyo = 0;
			
			while((linea = br.readLine()) != null) { //recorremos el archivo a la espera de recibir un valor nulo cuando se termine el documento que rompa el bucle
				int valor = Integer.parseInt(linea);
				if(valor >= 25) { //condición para incrementar verano si recibimos un valor mayor o igual que 25
					verano++;
				} else if (valor < 25 && valor > 10) { //condición de incremento de otoño, valor entre 25 y 10
					otonyo++;
				} else if (valor <= 10) { //condición de incremento de invierno, valor menor o igual que 10
					invierno++;
				}
			}
			 //finalmente guardamos los valores finales en el array
			resultado[0] = verano;
			resultado[1] = otonyo;
			resultado[2] = invierno;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultado;
	}

	//Escritura de fichero de texto con 10 temperaturas aleatorias entre -5 y 35 grados.
	private static void generaFicheroTempTexto() {
		Random rand = new Random();
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter("res/temperaturas.txt"));
			// Generamos 10 días de temperaturas
			for (int i = 0; i < 10; i++) {
				int temperatura = rand.nextInt(40) - 5; // Rango de temperatura entre -5 y 35 generado aleatoriamente
				writer.write(String.valueOf(temperatura));
				writer.newLine();
			}
			System.out.println("Fichero temperaturas.txt generado correctamente.");
		} catch (IOException e) {
			System.out.println("Error al escribir el archivo res/temperaturas.txt: " + e.getMessage());
		} finally {
			try {
				writer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}

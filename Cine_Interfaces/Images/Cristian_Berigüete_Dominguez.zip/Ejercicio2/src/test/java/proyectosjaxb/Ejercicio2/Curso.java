package proyectosjaxb.Ejercicio2;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Curso {

	private int curso;
	private int plazas;
	
	@XmlElement(name = "curso")
	public int getCurso() {
		return curso;
	}
	public void setCurso(int curso) {
		this.curso = curso;
	}
	
	@XmlAttribute(name = "plazas")
	public int getPlazas() {
		return plazas;
	}
	public void setPlazas(int plazas) {
		this.plazas = plazas;
	}
}

package proyectosjaxb.Ejercicio2;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType
@XmlRootElement(name = "instituto")
@XmlType(propOrder = {"listaCiclos","direccion"})
public class Instituto {
	
	private String nombre;
	private ArrayList <Ciclo> listaCiclos;
	private String direccion;
	
	@XmlAttribute(name = "nombre")
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	@XmlElementWrapper(name = "ciclos")
	@XmlElement(name = "ciclo")
	public ArrayList<Ciclo> getListaCiclos() {
		return listaCiclos;
	}
	public void setListaCiclos(ArrayList<Ciclo> listaCiclos) {
		this.listaCiclos = listaCiclos;
	}
	
	@XmlElement(name = "direccion")
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	
	
	
}

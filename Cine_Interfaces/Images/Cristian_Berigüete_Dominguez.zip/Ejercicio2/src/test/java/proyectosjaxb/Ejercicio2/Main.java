package proyectosjaxb.Ejercicio2;

import java.io.File;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

public class Main {

	public static void main(String[] args) {
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(Instituto.class);
			Marshaller marshaller = jaxbContext.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			File f = new File("instituto.xml");
			
			if(!f.exists()) {
				f.createNewFile();
			} 
			
			//Creación del primer ciclo junto a su objeto curso
			Curso curso1 = new Curso();
			curso1.setPlazas(30);
			curso1.setCurso(1);
			
			Ciclo ciclo1 = new Ciclo();
			ciclo1.setNombre("DAM");
			ciclo1.setCurso(curso1);
			
			//Creación del segundo ciclo junto a su objeto curso
			Curso curso2 = new Curso();
			curso2.setPlazas(30);
			curso2.setCurso(2);
			
			Ciclo ciclo2 = new Ciclo();
			ciclo2.setNombre("DAM");
			ciclo2.setCurso(curso2);
			
			//Creación del tercer ciclo junto a su objeto curso
			Curso curso3 = new Curso();
			curso3.setPlazas(30);
			curso3.setCurso(1);
			
			Ciclo ciclo3 = new Ciclo();
			ciclo3.setNombre("ASIR");
			ciclo3.setCurso(curso3);
			
			//Creación del cuarto ciclo junto a su objeto curso
			Curso curso4 = new Curso();
			curso4.setPlazas(30);
			curso4.setCurso(2);
			
			Ciclo ciclo4 = new Ciclo();
			ciclo4.setNombre("ASIR");
			ciclo4.setCurso(curso4);
			
			//Creación del objeto instituto
			ArrayList <Ciclo> listaCiclos = new ArrayList <Ciclo>(); //Creamos una lista para guardar los cilcos y pasarla al seter de instituto
			listaCiclos.add(ciclo1);
			listaCiclos.add(ciclo2);
			listaCiclos.add(ciclo3);
			listaCiclos.add(ciclo4);
			
			Instituto inst = new Instituto(); //Cramos el objeto y establecemos sus datos a través de sus seters
			inst.setNombre("IES Villaverde");
			inst.setListaCiclos(listaCiclos);
			inst.setDireccion("Calle Alianza 19, 28041, Madrid");
			
			//Finalmente construimos el documento y lo imprimimos por pantalla
			marshaller.marshal(inst,f);
			marshaller.marshal(inst,System.out);
			System.out.println("Archivo xml generado: " + f.getName());
		
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
